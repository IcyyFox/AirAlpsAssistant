
 ______     __     ______        ______     __         ______   ______    
/\  __ \   /\ \   /\  == \      /\  __ \   /\ \       /\  == \ /\  ___\   
\ \  __ \  \ \ \  \ \  __<      \ \  __ \  \ \ \____  \ \  _-/ \ \___  \  
 \ \_\ \_\  \ \_\  \ \_\ \_\     \ \_\ \_\  \ \_____\  \ \_\    \/\_____\ 
  \/_/\/_/   \/_/   \/_/ /_/      \/_/\/_/   \/_____/   \/_/     \/_____/ 
                                                                          
------------------------------------------------------------------------------------------------------------------------------------
Thanks for choosing AirAlps as your airline.
This is a Guide telling you how you can use the Air Alps Flight logging Assistant.
IMPORTANT: This Guide does not support Linux or Mac. 
To use the Air Alps Assistant, You need to download Python another way.

Step 1. Installing Python (Don't worry, it's easy)

If you know you already have Python, you can skip this step.
If you're not sure, do this step anyways.

Go to this link: https://www.microsoft.com/store/productId/9NRWMJP3717K
This will send you to the official microsoft store page for Python 3.11.
Click the download button, and when it finishes, Python will be fully installed on your computer.

Step 2. Starting the Assistant

In this Folder, there is a File named "AirAlps Assistant v1".
Open it by double clicking on it, and if step 1 has been completed, it will start as intended
and  you'll be able to log your flights easier!
To make it even more convenient, move the Assistant to your "Desktop" Folder or Create a desktop shortcut to it.

Happy logging!



